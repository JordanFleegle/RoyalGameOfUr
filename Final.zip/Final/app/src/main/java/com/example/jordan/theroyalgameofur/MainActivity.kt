package com.example.jordan.theroyalgameofur

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import java.util.*

class MainActivity : AppCompatActivity() {
    val PLayer1 : Int = 0
    val Player2 : Int = 0
    var random = Random()
    var timer = Timer()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btnStart = findViewById<ImageButton>(R.id.imgBtnStart)

        btnStart.setOnClickListener{
            if (btnStart.text == "Start"){


            }
        }

    }

}
